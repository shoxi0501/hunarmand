# Responsive Fashion E-commerce Website Template with HTML, CSS & JavaScript

![Responsive Fashion E-commerce Website Template with HTML, CSS and JavaScript](https://raw.githubusercontent.com/wpcodevo/lc28-fashion-ecommerce-website/starter/fashion%20ecommerce%20website%20html%20css%20scss%20javascript.png 'Responsive Fashion E-commerce Website Template with HTML, CSS and JavaScript')

The Figma file of the Responsive Fashion E-commerce Website Template can be found on my [website](https://www.codevoweb.com)
