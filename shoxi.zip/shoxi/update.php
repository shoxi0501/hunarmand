<?php


include 'connection.php';
if (isset($_POST['name']) 
&& isset($_POST['category'])  
&& isset($_POST['recipe']) 
&& isset($_POST['price'])  

) {
    $category = $_POST['category'];
    $name = $_POST['name'];
    $recipe = $_POST['recipe'];
    $price = $_POST['price'];
//rasm uchun
$filename = $_FILES["image"]["name"];
$tempname = $_FILES["image"]["tmp_name"];
$folder = "image/" . $filename;
if(move_uploaded_file($tempname,$folder)){
    echo "rasm yuklandi!";
}
else echo "rasm yuklashda xatolik";

    $id = intval($_POST['id']);
    $sql = "UPDATE food SET  category='$category', name='$name', recipe='$recipe', price='$price', image='$filename'   
       WHERE id = '$id';";
    if ($connection->query($sql)) {
        header('Location: food.php'); 
    } else echo 'xato!' . $connection->error;
}
$connection->close();
