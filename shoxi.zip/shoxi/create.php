<?php
include 'connect.php';
if (isset($_POST['s1'])) {
    $name = $_POST['name'];
    $recipe = $_POST['recipe'];
    $price = $_POST['price'];
//rasm uchun
$filename = $_FILES["image"]["name"];
$tempname = $_FILES["image"]["tmp_name"];
$folder = "image/" . $filename;
if(move_uploaded_file($tempname,$folder)){
    echo "rasm yuklandi!";
}
else echo "rasm yuklashda xatolik";

    $sql = "INSERT INTO `maxsulot`( `nomi`, `matni`, `narxi`, `rasmi`) 
    VALUES (' $name','$recipe',' $price','$filename')";
    if ($connection->query($sql)) 
    {
        ?>
      <script type="javascript">alert("Saqlandi")</script>
      <?php
        header("Location:maxsulot.php");
    } else echo 'xato!' . $connection->error;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <title>Kategoriya qo'shish</title>
</head>
<body>
<div class="text-left">
        <a href="admin.php" style="color: #9F0053" class="btn btn-block mb-2 "><h3>Admin menyuga qaytish</h3></a>
    </div>
    <h2 align="center">Maxsulot yartish
    </h2>

<form action="" method="post" enctype="multipart/form-data">
    
  <div class="form-group">
    <label for="name">Nomi </label>
    <input type="text" class="form-control" id="name"  name="name">
  </div>

  <div class="form-group">
    <label for="recipe">Matni </label>
    <input type="text" class="form-control" id="recipe"  name="recipe">
  </div>

  <div class="form-group">
    <label for="price">Narxi</label>
    <input type="text" class="form-control" id="price"  name="price">
  </div>

  <div class="form-group">
    <label for="image">Rasmi</label>
    <input type="file" class="form-control" id="image"  name="image">
  </div>
  <button class="btn btn-primary" type="submit" name="s1">Save</button>
</form>
</body>
</html>