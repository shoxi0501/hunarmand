<?php
include 'connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Favicon -->
     <link href="img/favicon.ico" rel="icon">

<!-- Google Font -->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;400&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet"> 

<!-- Font Awesome -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

<!-- Libraries Stylesheet -->
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

<!-- Customized Bootstrap Stylesheet -->

    <title>Admin</title>
</head>
<body>
<table class="table table-hover" border="2">
        <thead>
        <tr>
            <th>ID</th>
            <th>Ismi</th>
            <th>Pochtasi </th>
            <th>Telefoni</th>
            <th>xabari</th>
        </tr>
        </thead>
        <tbody>
        <?php 
        $sql = "SELECT * FROM xabar";
        $result = $connection->query($sql);
        if($result->num_rows>0){
            while($row = $result->fetch_assoc())

            {
                ?>
                <tr>
                    <td><?php echo $row['id']?></td>
                    <td><?php echo $row['ism']?></td>
                    <td><?php echo $row['pochta']?></td>
                    <td><?php echo $row['telefon']?></td>
                    <td><?php echo $row['xabar']?></td>
                </tr>
            <?php }}?>
        </tbody>
    </table>
</body>
</html>