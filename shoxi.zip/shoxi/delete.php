<?php
include 'connect.php';
$id = $_POST['id'];
$sql = "DELETE FROM maxsulot where id='$id'";
if ($connection->query($sql) === TRUE) {
    header("Location:maxsulot.php");
} else echo $connection->error;
